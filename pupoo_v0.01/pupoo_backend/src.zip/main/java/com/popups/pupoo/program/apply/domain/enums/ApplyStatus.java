package com.popups.pupoo.program.apply.domain.enums;

public enum ApplyStatus {

}
