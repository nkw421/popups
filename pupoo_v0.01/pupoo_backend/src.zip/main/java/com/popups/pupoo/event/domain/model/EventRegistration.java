package com.popups.pupoo.event.domain.model;

public class EventRegistration {

}
