package com.popups.pupoo.event.application;

public class EventRegistrationService {

}
