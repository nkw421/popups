package com.popups.pupoo.qr.domain.model;

public class QrCode {

}
