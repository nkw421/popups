package com.popups.pupoo.payment.dto;

public class PaymentResponse {

}
