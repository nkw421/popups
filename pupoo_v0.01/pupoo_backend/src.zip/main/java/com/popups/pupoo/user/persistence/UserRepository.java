// src/main/java/com/popups/pupoo/user/persistence/UserRepository.java
package com.popups.pupoo.user.persistence;

import com.popups.pupoo.user.domain.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    boolean existsByEmail(String email);

    boolean existsByPhone(String phone);

    boolean existsByNickname(String nickname);
}
