package com.popups.pupoo.notification.dto;

public class NotificationResponse {

}
