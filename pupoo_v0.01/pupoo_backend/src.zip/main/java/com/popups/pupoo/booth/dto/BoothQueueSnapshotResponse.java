package com.popups.pupoo.booth.dto;

public class BoothQueueSnapshotResponse {

}
