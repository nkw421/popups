package com.popups.pupoo.interest.domain;

public class UserInterestSubscription {

}
