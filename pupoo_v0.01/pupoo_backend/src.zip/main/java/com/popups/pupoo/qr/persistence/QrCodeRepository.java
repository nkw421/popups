package com.popups.pupoo.qr.persistence;

public interface QrCodeRepository {

}
