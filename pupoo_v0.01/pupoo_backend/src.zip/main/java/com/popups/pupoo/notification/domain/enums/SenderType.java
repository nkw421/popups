package com.popups.pupoo.notification.domain.enums;

public enum SenderType {

}
