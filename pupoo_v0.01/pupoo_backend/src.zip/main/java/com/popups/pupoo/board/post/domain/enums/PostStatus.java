package com.popups.pupoo.board.post.domain.enums;

public enum PostStatus {

}
