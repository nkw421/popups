package com.popups.pupoo.user.social.dto;

public class SocialAccountResponse {

}
