package com.popups.pupoo.board.review.persistence;

public interface ReviewRepository {

}
