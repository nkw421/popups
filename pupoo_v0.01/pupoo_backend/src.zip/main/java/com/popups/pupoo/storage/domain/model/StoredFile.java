package com.popups.pupoo.storage.domain.model;

public class StoredFile {

}
