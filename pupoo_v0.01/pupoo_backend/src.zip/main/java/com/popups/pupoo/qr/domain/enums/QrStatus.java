package com.popups.pupoo.qr.domain.enums;

public enum QrStatus {

}
