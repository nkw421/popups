package com.popups.pupoo.common.enumtype;

public enum RoleType {

}
