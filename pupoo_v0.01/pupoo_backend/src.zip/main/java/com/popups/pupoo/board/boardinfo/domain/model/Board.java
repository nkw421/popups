package com.popups.pupoo.board.boardinfo.domain.model;

public class Board {

}
