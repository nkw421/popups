package com.popups.pupoo.inquiry.dto;

public class InquiryCreateRequest {

}
