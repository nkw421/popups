package com.popups.pupoo.interest.persistence;

public interface UserInterestSubscriptionRepository {

}
