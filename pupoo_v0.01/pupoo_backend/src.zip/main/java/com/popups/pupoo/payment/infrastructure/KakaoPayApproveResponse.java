package com.popups.pupoo.payment.infrastructure;

public class KakaoPayApproveResponse {

}
