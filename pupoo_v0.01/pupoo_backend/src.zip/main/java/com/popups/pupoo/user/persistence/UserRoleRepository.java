package com.popups.pupoo.user.persistence;

public interface UserRoleRepository {

}
