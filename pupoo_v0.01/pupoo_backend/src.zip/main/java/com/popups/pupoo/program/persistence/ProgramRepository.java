package com.popups.pupoo.program.persistence;

public interface ProgramRepository {

}
