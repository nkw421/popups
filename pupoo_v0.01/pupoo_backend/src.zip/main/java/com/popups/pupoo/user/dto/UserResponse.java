package com.popups.pupoo.user.dto;

public class UserResponse {

}
