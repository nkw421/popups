package com.popups.pupoo.program.apply.dto;

public class ProgramApplyRequest {

}
