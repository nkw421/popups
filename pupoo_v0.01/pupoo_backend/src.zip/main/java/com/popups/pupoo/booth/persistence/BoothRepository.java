package com.popups.pupoo.booth.persistence;

public interface BoothRepository {

}
