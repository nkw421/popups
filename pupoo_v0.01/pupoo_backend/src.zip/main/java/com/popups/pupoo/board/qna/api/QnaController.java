package com.popups.pupoo.board.qna.api;

public class QnaController {

}
