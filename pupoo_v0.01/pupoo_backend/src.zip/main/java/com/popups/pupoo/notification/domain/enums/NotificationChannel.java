package com.popups.pupoo.notification.domain.enums;

public enum NotificationChannel {
    APP,
    EMAIL,
    SMS,
    PUSH
}
