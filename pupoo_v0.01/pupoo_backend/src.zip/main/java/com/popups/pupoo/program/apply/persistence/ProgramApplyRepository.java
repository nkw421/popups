package com.popups.pupoo.program.apply.persistence;

public interface ProgramApplyRepository {

}
