package com.popups.pupoo.notification.infrastructure;

public interface InAppNotificationSender {

}
