package com.popups.pupoo.board.boardinfo.persistence;

public interface BoardRepository {

}
