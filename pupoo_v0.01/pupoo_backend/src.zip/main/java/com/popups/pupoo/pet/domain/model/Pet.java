package com.popups.pupoo.pet.domain.model;

public class Pet {

}
