package com.popups.pupoo.user.social.persistence;

public interface SocialAccountRepository {

}
