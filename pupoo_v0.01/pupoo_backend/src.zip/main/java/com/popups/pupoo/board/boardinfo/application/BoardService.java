package com.popups.pupoo.board.boardinfo.application;

public class BoardService {

}
