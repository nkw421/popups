package com.popups.pupoo.board.boardinfo.dto;

public class BoardCreateRequest {

}
