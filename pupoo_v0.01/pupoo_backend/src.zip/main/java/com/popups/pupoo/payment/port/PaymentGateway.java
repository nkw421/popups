package com.popups.pupoo.payment.port;

public class PaymentGateway {

}
