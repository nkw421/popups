package com.popups.pupoo.notification.persistence;

public interface NotificationRepository {

}
