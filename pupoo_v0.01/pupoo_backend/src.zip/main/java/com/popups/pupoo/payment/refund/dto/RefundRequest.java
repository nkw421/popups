package com.popups.pupoo.payment.refund.dto;

public class RefundRequest {

}
