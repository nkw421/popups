package com.popups.pupoo.storage.infrastructure;

public class LocalStorageClient {

}
