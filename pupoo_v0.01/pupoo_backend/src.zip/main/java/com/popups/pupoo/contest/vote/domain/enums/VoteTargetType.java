package com.popups.pupoo.contest.vote.domain.enums;

public enum VoteTargetType {

}
