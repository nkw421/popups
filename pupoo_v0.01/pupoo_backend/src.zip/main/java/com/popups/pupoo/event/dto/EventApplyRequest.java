package com.popups.pupoo.event.dto;

public class EventApplyRequest {

}
