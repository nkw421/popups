package com.popups.pupoo.payment.refund.persistence;

public interface RefundRepository {

}
