package com.popups.pupoo.board.boardinfo.dto;

public class BoardResponse {

}
