package com.popups.pupoo.gallery.persistence;

public interface GalleryRepository {

}
