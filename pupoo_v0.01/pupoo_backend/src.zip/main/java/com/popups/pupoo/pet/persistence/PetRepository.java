package com.popups.pupoo.pet.persistence;

public interface PetRepository {

}
