package com.popups.pupoo.user.domain.model;

public class UserRole {

}
