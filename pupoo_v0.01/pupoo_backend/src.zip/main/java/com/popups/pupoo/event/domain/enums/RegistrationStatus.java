package com.popups.pupoo.event.domain.enums;

public enum RegistrationStatus {

}
