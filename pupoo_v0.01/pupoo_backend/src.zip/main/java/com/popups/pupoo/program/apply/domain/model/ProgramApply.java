package com.popups.pupoo.program.apply.domain.model;

public class ProgramApply {

}
