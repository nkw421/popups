package com.popups.pupoo.board.common.dto;

public class BoardSearchRequest {

}
