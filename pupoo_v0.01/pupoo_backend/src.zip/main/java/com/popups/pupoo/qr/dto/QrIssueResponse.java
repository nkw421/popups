package com.popups.pupoo.qr.dto;

public class QrIssueResponse {

}
