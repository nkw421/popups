package com.popups.pupoo.auth.domain.enums;

public enum TokenType {

}
