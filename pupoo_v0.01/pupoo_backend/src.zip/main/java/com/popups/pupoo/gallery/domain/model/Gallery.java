package com.popups.pupoo.gallery.domain.model;

public class Gallery {

}
