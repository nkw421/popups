package com.popups.pupoo.notification.domain.model;

public class NotificationInbox {

}
