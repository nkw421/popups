package com.popups.pupoo.board.post.persistence;

public interface PostRepository {

}
