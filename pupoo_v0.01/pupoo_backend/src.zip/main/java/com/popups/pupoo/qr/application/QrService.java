package com.popups.pupoo.qr.application;

public class QrService {

}
