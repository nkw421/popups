package com.popups.pupoo.notification.port;

public interface NotificationSender {

}
