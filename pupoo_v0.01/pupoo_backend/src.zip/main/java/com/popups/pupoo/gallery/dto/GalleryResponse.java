package com.popups.pupoo.gallery.dto;

public class GalleryResponse {

}
