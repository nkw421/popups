package com.popups.pupoo.contest.vote.persistence;

public interface ContestVoteRepository {

}
