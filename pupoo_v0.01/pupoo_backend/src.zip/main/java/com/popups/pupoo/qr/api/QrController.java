package com.popups.pupoo.qr.api;

public class QrController {

}
