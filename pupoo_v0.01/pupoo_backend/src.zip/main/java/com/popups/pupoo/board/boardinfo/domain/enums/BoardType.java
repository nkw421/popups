package com.popups.pupoo.board.boardinfo.domain.enums;

public enum BoardType {

}
