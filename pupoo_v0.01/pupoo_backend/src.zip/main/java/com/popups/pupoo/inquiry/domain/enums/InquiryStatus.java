package com.popups.pupoo.inquiry.domain.enums;

public enum InquiryStatus {

}
