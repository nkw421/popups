package com.popups.pupoo.interest.dto;

public class InterestResponse {

}
