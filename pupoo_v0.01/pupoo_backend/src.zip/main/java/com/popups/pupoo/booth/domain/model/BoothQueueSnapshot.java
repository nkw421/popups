package com.popups.pupoo.booth.domain.model;

public class BoothQueueSnapshot {

}
