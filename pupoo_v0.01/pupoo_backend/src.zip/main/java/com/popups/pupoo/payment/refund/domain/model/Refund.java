package com.popups.pupoo.payment.refund.domain.model;

public class Refund {

}
