package com.popups.pupoo.pet.dto;

public class PetResponse {

}
