package com.popups.pupoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PupooBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PupooBackendApplication.class, args);
	}

}
