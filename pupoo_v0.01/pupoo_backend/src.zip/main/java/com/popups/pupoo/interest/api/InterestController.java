package com.popups.pupoo.interest.api;

public class InterestController {

}
