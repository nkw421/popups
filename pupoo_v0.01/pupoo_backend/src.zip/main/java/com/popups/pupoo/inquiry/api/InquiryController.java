package com.popups.pupoo.inquiry.api;

public class InquiryController {

}
