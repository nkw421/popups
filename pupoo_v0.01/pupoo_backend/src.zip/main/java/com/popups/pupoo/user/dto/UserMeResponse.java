package com.popups.pupoo.user.dto;

public class UserMeResponse {

}
