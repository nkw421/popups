package com.popups.pupoo.pet.domain.enums;

public enum PetGender {
    MALE,
    FEMALE,
    UNKNOWN
}
