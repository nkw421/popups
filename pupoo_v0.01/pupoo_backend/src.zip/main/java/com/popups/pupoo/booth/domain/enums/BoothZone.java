package com.popups.pupoo.booth.domain.enums;

public enum BoothZone {
    ZONE_A,
    ZONE_B,
    ZONE_C,
    OTHER
}
