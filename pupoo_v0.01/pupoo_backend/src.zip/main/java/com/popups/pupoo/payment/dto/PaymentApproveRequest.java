package com.popups.pupoo.payment.dto;

public class PaymentApproveRequest {

}
