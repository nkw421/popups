package com.popups.pupoo.storage.dto;

public class FileResponse {

}
