package com.popups.pupoo.interest.application;

public class InterestService {

}
