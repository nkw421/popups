package com.popups.pupoo.board.qna.persistence;

public interface QnaRepository {

}
