package com.popups.pupoo.reply.persistence;

public interface ReplyRepository {

}
