package com.popups.pupoo.inquiry.domain.enums;

public enum InquiryCategory {
    EVENT,
    PAYMENT,
    REFUND,
    ACCOUNT,
    OTHER
}
