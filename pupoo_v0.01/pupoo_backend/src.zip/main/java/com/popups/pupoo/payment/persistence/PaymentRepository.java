package com.popups.pupoo.payment.persistence;

public interface PaymentRepository {

}
