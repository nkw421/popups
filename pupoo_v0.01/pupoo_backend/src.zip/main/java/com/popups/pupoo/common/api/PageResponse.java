package com.popups.pupoo.common.api;

public class PageResponse {

}
