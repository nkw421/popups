package com.popups.pupoo.interest.domain.enums;

public enum InterestName {
    EVENT,
    SESSION,
    EXPERIENCE,
    BOOTH,
    CONTEST,
    NOTICE,
    OTHER
}
