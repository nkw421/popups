package com.popups.pupoo.booth.application;

public class BoothService {

}
