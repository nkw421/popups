package com.popups.pupoo.contest.vote.api;

public class ContestVoteController {

}
