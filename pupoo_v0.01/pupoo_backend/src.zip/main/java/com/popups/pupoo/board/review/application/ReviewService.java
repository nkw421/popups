package com.popups.pupoo.board.review.application;

public class ReviewService {

}
