package com.popups.pupoo.program.speaker.persistence;

public interface SpeakerRepository {

}
