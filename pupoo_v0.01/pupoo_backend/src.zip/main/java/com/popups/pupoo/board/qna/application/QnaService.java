package com.popups.pupoo.board.qna.application;

public class QnaService {

}
