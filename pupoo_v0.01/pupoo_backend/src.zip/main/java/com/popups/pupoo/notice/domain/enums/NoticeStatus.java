package com.popups.pupoo.notice.domain.enums;

public enum NoticeStatus {

}
