package com.popups.pupoo.event.persistence;

public interface EventRegistrationRepository {

}
