package com.popups.pupoo.interest.domain.enums;

public enum SubscriptionStatus {

}
