package com.popups.pupoo.contest.vote.domain.model;

public class ContestVote {

}
