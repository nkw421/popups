package com.popups.pupoo.board.post.dto;

public class PostResponse {

}
