package com.popups.pupoo.payment.domain.model;

public class Payment {

}
