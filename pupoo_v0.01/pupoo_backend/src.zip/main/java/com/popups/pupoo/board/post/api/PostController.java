package com.popups.pupoo.board.post.api;

public class PostController {

}
