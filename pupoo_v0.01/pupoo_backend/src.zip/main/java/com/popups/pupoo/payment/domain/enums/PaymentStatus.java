package com.popups.pupoo.payment.domain.enums;

public enum PaymentStatus {

}
