package com.popups.pupoo.storage.persistence;

public interface StoredFileRepository {

}
