package com.popups.pupoo.contest.vote.dto;

public class ContestVoteRequest {

}
