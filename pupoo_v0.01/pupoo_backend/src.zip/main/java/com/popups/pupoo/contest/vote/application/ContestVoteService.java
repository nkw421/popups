package com.popups.pupoo.contest.vote.application;

public class ContestVoteService {

}
