// src/main/java/com/popups/pupoo/user/domain/enums/UserStatus.java
package com.popups.pupoo.user.domain.enums;

public enum UserStatus {

    ACTIVE,      // 정상
    INACTIVE,    // 탈퇴
    SUSPENDED    // 정지

}
