package com.popups.pupoo.notice.domain.model;

public class Notice {

}
