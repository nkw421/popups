package com.popups.pupoo.common.enumtype;

public class YesNo {

}
