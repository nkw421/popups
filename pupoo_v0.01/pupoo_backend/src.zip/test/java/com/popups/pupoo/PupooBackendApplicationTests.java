package com.popups.pupoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PupooBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
