package com.popups.pupoo.notification.port;

import com.popups.pupoo.notification.domain.enums.NotificationChannel;
import com.popups.pupoo.notification.domain.enums.SenderType;
import lombok.Getter;

/**
 * 알림 발송 Port
 *
 * - APP/EMAIL/SMS/PUSH 등 채널별 구현체는 notification.infrastructure 하위에 둔다.
 * - 현재 MVP는 INAPP(=inbox 적재) 우선.
 */
public interface NotificationSender {

    void send(SendCommand command);

    @Getter
    class SendCommand {
        private final Long notificationId;
        private final Long receiverUserId;
        private final Long senderId;
        private final SenderType senderType;
        private final NotificationChannel channel;

        public SendCommand(Long notificationId,
                           Long receiverUserId,
                           Long senderId,
                           SenderType senderType,
                           NotificationChannel channel) {
            this.notificationId = notificationId;
            this.receiverUserId = receiverUserId;
            this.senderId = senderId;
            this.senderType = senderType;
            this.channel = channel;
        }
    }
}
