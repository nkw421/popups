package com.popups.pupoo.notification.infrastructure;

import com.popups.pupoo.notification.port.NotificationSender;
import org.springframework.stereotype.Component;

/**
 * INAPP 채널 구현체.
 *
 * 현재 설계에서는 "인앱 발송" 자체가 notification_inbox 적재로 완료된다.
 * 따라서 이 구현체는 외부 연동이 필요해질 때(푸시/웹소켓 등) 확장용으로 둔다.
 */
@Component
public class InAppNotificationSender implements NotificationSender {

    @Override
    public void send(NotificationSender.SendCommand command) {
        // NO-OP (MVP)
        // - 인앱은 inbox insert로 완료
        // - 추후 WebSocket/SSE/FCM 등으로 실시간 push를 붙일 때 여기서 처리
    }
}
