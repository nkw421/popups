package com.popups.pupoo.notification.domain.enums;

public enum SenderType {
    USER,
    ADMIN,
    SYSTEM
}
