package com.popups.pupoo.notification.domain.enums;

public enum NotificationType {

    EVENT,
    EVENT_INFO,
    NOTICE,
    PAYMENT,
    APPLY,
    SYSTEM
}
