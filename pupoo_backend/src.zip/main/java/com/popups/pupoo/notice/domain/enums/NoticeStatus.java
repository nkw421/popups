package com.popups.pupoo.notice.domain.enums;

public enum NoticeStatus {
    DRAFT,      // 임시저장
    PUBLISHED,  // 게시
    HIDDEN      // 비공개
}