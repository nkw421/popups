package com.popups.pupoo.notice.persistence;

public interface NoticeRepository {

}
