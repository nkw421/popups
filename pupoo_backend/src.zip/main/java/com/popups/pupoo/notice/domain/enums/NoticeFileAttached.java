package com.popups.pupoo.notice.domain.enums;

public enum NoticeFileAttached {
    Y, N
}