package com.popups.pupoo.notice.dto;

public class NoticeResponse {

}
