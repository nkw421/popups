package com.popups.pupoo.storage.dto;

import com.popups.pupoo.common.exception.BusinessException;
import com.popups.pupoo.common.exception.ErrorCode;
import com.popups.pupoo.storage.infrastructure.StorageKeyGenerator;

public class UploadRequest {

    private String targetType; // POST / NOTICE (GALLERY/QR are handled by their own domains)
    private Long contentId;    // postId or noticeId

    public UploadRequest() {}

    public UploadRequest(String targetType, Long contentId) {
        this.targetType = targetType;
        this.contentId = contentId;
    }

    public StorageKeyGenerator.UploadTargetType parsedTargetType() {
        if (targetType == null || targetType.isBlank()) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, "targetType is required");
        }
        try {
            return StorageKeyGenerator.UploadTargetType.valueOf(targetType.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, "invalid targetType: " + targetType);
        }
    }

    public void validateForFilesTable() {
        StorageKeyGenerator.UploadTargetType t = parsedTargetType();
        if (t != StorageKeyGenerator.UploadTargetType.POST && t != StorageKeyGenerator.UploadTargetType.NOTICE) {
            throw new BusinessException(ErrorCode.INVALID_REQUEST,
                    "This endpoint supports POST/NOTICE only. Use Gallery/QR APIs for other types.");
        }
        if (contentId == null || contentId <= 0) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, "contentId is required");
        }
    }

    public String getTargetType() {
        return targetType;
    }

    public Long getContentId() {
        return contentId;
    }

    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }

    public void setContentId(Long contentId) {
        this.contentId = contentId;
    }
}
