package com.popups.pupoo.storage.application;

import com.popups.pupoo.common.exception.BusinessException;
import com.popups.pupoo.common.exception.ErrorCode;
import com.popups.pupoo.storage.domain.model.StoredFile;
import com.popups.pupoo.storage.dto.FileResponse;
import com.popups.pupoo.storage.dto.UploadRequest;
import com.popups.pupoo.storage.dto.UploadResponse;
import com.popups.pupoo.storage.infrastructure.StorageKeyGenerator;
import com.popups.pupoo.storage.persistence.StoredFileRepository;
import com.popups.pupoo.storage.port.ObjectStoragePort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

@Service
public class StorageService {

    private static final String LOCAL_BUCKET_UNUSED = "local";

    private final ObjectStoragePort objectStoragePort;
    private final StorageKeyGenerator keyGenerator;
    private final StoredFileRepository storedFileRepository;

    public StorageService(ObjectStoragePort objectStoragePort,
                          StorageKeyGenerator keyGenerator,
                          StoredFileRepository storedFileRepository) {
        this.objectStoragePort = objectStoragePort;
        this.keyGenerator = keyGenerator;
        this.storedFileRepository = storedFileRepository;
    }

    /**
     * POST/NOTICE attachment upload -> files table.
     * Public access is served by Nginx: /static/**
     */
    @Transactional
    public UploadResponse uploadForFilesTable(MultipartFile file, UploadRequest request) {
        request.validateForFilesTable();
        if (file == null || file.isEmpty()) {
            throw new BusinessException(ErrorCode.VALIDATION_FAILED, "file is required");
        }

        StorageKeyGenerator.UploadTargetType type = request.parsedTargetType();
        Long contentId = request.getContentId();
        String originalName = safeOriginalName(file.getOriginalFilename());

        String key = keyGenerator.generateKey(type, contentId, originalName);
        String storedName = key.substring(key.lastIndexOf('/') + 1);

        try {
            objectStoragePort.putObject(LOCAL_BUCKET_UNUSED, key, file.getBytes(), file.getContentType());
        } catch (IOException e) {
            throw new BusinessException(ErrorCode.INTERNAL_ERROR, "Failed to read upload bytes: " + e.getMessage());
        }

        StoredFile storedFile = (type == StorageKeyGenerator.UploadTargetType.POST)
                ? StoredFile.forPost(originalName, storedName, contentId)
                : StoredFile.forNotice(originalName, storedName, contentId);

        StoredFile saved = storedFileRepository.save(storedFile);
        String publicPath = objectStoragePort.getPublicPath(LOCAL_BUCKET_UNUSED, key);

        return UploadResponse.of(saved.getFileId(), saved.getOriginalName(), saved.getStoredName(), publicPath);
    }

    @Transactional(readOnly = true)
    public FileResponse getFile(Long fileId) {
        StoredFile f = storedFileRepository.findById(fileId)
                .orElseThrow(() -> new BusinessException(ErrorCode.RESOURCE_NOT_FOUND, "file not found"));
        String key = toKey(f);
        String publicPath = objectStoragePort.getPublicPath(LOCAL_BUCKET_UNUSED, key);
        return FileResponse.of(f.getFileId(), f.getOriginalName(), publicPath);
    }

    @Transactional(readOnly = true)
    public InputStream download(Long fileId) {
        StoredFile f = storedFileRepository.findById(fileId)
                .orElseThrow(() -> new BusinessException(ErrorCode.RESOURCE_NOT_FOUND, "file not found"));
        String key = toKey(f);
        return objectStoragePort.getObject(LOCAL_BUCKET_UNUSED, key);
    }

    @Transactional
    public void delete(Long fileId) {
        StoredFile f = storedFileRepository.findById(fileId)
                .orElseThrow(() -> new BusinessException(ErrorCode.RESOURCE_NOT_FOUND, "file not found"));
        String key = toKey(f);
        objectStoragePort.deleteObject(LOCAL_BUCKET_UNUSED, key);
        storedFileRepository.delete(f);
    }

    private String toKey(StoredFile f) {
        if (f.getPostId() != null) {
            return keyGenerator.buildKey(StorageKeyGenerator.UploadTargetType.POST, f.getPostId(), f.getStoredName());
        }
        if (f.getNoticeId() != null) {
            return keyGenerator.buildKey(StorageKeyGenerator.UploadTargetType.NOTICE, f.getNoticeId(), f.getStoredName());
        }
        throw new BusinessException(ErrorCode.INTERNAL_ERROR, "files row has no owner (post_id/notice_id)");
    }

    private static String safeOriginalName(String originalFilename) {
        if (originalFilename == null || originalFilename.isBlank()) return "file";
        // Strip any path elements
        int idx1 = originalFilename.lastIndexOf('/');
        int idx2 = originalFilename.lastIndexOf('\\');
        int idx = Math.max(idx1, idx2);
        return (idx >= 0) ? originalFilename.substring(idx + 1) : originalFilename;
    }
}
