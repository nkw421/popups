package com.popups.pupoo.storage.dto;

public class FileResponse {

    private Long fileId;
    private String originalName;
    private String publicPath;

    public FileResponse() {}

    public FileResponse(Long fileId, String originalName, String publicPath) {
        this.fileId = fileId;
        this.originalName = originalName;
        this.publicPath = publicPath;
    }

    public static FileResponse of(Long fileId, String originalName, String publicPath) {
        return new FileResponse(fileId, originalName, publicPath);
    }

    public Long getFileId() {
        return fileId;
    }

    public String getOriginalName() {
        return originalName;
    }

    public String getPublicPath() {
        return publicPath;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public void setOriginalName(String originalName) {
        this.originalName = originalName;
    }

    public void setPublicPath(String publicPath) {
        this.publicPath = publicPath;
    }
}
