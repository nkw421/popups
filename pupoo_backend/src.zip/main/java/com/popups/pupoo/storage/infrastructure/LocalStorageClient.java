package com.popups.pupoo.storage.infrastructure;

import com.popups.pupoo.common.exception.BusinessException;
import com.popups.pupoo.common.exception.ErrorCode;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.*;

/**
 * Low-level local filesystem client.
 * Uses atomic write (temp file + move) to reduce partial writes.
 */
@Component
public class LocalStorageClient {

    public void write(Path absolutePath, byte[] bytes) {
        try {
            Path parent = absolutePath.getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }

            Path tmp = Files.createTempFile(parent, ".upload-", ".tmp");
            Files.write(tmp, bytes, StandardOpenOption.TRUNCATE_EXISTING);
            Files.move(tmp, absolutePath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            throw new BusinessException(ErrorCode.INTERNAL_ERROR, "Failed to write file: " + e.getMessage());
        }
    }

    public InputStream read(Path absolutePath) {
        try {
            byte[] bytes = Files.readAllBytes(absolutePath);
            return new ByteArrayInputStream(bytes);
        } catch (NoSuchFileException e) {
            throw new BusinessException(ErrorCode.RESOURCE_NOT_FOUND, "File not found");
        } catch (IOException e) {
            throw new BusinessException(ErrorCode.INTERNAL_ERROR, "Failed to read file: " + e.getMessage());
        }
    }

    public void delete(Path absolutePath) {
        try {
            Files.deleteIfExists(absolutePath);
        } catch (IOException e) {
            throw new BusinessException(ErrorCode.INTERNAL_ERROR, "Failed to delete file: " + e.getMessage());
        }
    }

    public boolean exists(Path absolutePath) {
        return Files.exists(absolutePath);
    }
}
