package com.popups.pupoo.storage.port;

import java.io.InputStream;

/**
 * Object storage abstraction.
 *
 * - Local/Nginx: bucket is unused; basePath + key maps to a file.
 * - S3: bucket is real; key maps to an object.
 */
public interface ObjectStoragePort {

    void putObject(String bucket, String key, byte[] bytes, String contentType);

    InputStream getObject(String bucket, String key);

    void deleteObject(String bucket, String key);

    /**
     * Returns a PUBLIC URL path (e.g., /static/post/1/xxx.png) that Nginx can serve.
     */
    String getPublicPath(String bucket, String key);
}
