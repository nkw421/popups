package com.popups.pupoo.storage.dto;

public class UploadResponse {

    private Long fileId;
    private String originalName;
    private String storedName;
    private String publicPath; // e.g., /static/post/10/uuid.png

    public UploadResponse() {}

    public UploadResponse(Long fileId, String originalName, String storedName, String publicPath) {
        this.fileId = fileId;
        this.originalName = originalName;
        this.storedName = storedName;
        this.publicPath = publicPath;
    }

    public static UploadResponse of(Long fileId, String originalName, String storedName, String publicPath) {
        return new UploadResponse(fileId, originalName, storedName, publicPath);
    }

    public Long getFileId() {
        return fileId;
    }

    public String getOriginalName() {
        return originalName;
    }

    public String getStoredName() {
        return storedName;
    }

    public String getPublicPath() {
        return publicPath;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public void setOriginalName(String originalName) {
        this.originalName = originalName;
    }

    public void setStoredName(String storedName) {
        this.storedName = storedName;
    }

    public void setPublicPath(String publicPath) {
        this.publicPath = publicPath;
    }
}
