package com.popups.pupoo.qr.dto;

public class QrAdminRequest {
    private Long qrId;
    public Long getQrId() { return qrId; }
}
