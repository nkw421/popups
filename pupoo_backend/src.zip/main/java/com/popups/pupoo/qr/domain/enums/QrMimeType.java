package com.popups.pupoo.qr.domain.enums;

public enum QrMimeType {
    jpeg, jpg, png, gif, webp, tiff, svg
}
