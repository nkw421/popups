package com.popups.pupoo.qr.domain.enums;

public enum QrCheckType {
    CHECKIN, CHECKOUT
}
