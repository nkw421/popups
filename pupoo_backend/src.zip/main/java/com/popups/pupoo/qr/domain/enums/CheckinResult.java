package com.popups.pupoo.qr.domain.enums;

public enum CheckinResult {
    SUCCESS,
    FAIL
}
