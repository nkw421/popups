// com/popups/pupoo/pet/domain/enums/PetWeight.java
package com.popups.pupoo.pet.domain.enums;

/**
 * pet.pet_weight ENUM('XS','S','M','L','XL')
 */
public enum PetWeight {
    XS, S, M, L, XL
}
