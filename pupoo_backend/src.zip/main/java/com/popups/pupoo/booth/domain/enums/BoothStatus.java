package com.popups.pupoo.booth.domain.enums;

public enum BoothStatus {
    OPEN,
    CLOSED,
    PAUSED
}
