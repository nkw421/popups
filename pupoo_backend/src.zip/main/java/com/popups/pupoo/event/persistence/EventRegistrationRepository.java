package com.popups.pupoo.event.persistence;

import com.popups.pupoo.event.domain.enums.RegistrationStatus;
import com.popups.pupoo.event.domain.model.EventRegistration;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.Optional;

/**
 * event_apply 접근 Repository (엔티티명은 EventRegistration)
 */
public interface EventRegistrationRepository extends JpaRepository<EventRegistration, Long> {

    boolean existsByEventIdAndUserIdAndStatus(Long eventId, Long userId, RegistrationStatus status);

    Page<EventRegistration> findByUserId(Long userId, Pageable pageable);

    /**
     * ✅ 결제 승인 시 자동 승인용: APPLIED 상태 row를 락으로 잡고 가져오기
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("""
        select er
        from EventRegistration er
        where er.eventId = :eventId
          and er.userId = :userId
          and er.status = :status
    """)
    Optional<EventRegistration> findByEventIdAndUserIdAndStatusForUpdate(
            @Param("eventId") Long eventId,
            @Param("userId") Long userId,
            @Param("status") RegistrationStatus status
    );

    /**
     * ✅ 환불 완료 시 자동 취소용:
     * APPLIED/APPROVED 상태를 락으로 잡고 1건 가져오기
     * (CANCELLED/REJECTED는 대상 아님 → 멱등)
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("""
        select er
        from EventRegistration er
        where er.eventId = :eventId
          and er.userId = :userId
          and er.status in :statuses
    """)
    Optional<EventRegistration> findActiveByEventIdAndUserIdForUpdate(
            @Param("eventId") Long eventId,
            @Param("userId") Long userId,
            @Param("statuses") Collection<RegistrationStatus> statuses
    );
}
