package com.popups.pupoo.auth.dto;

public class RefreshTokenRequest {

}
