package com.popups.pupoo.gallery.application;

public class GalleryAdminService {
}
