package com.popups.pupoo.gallery.domain.enums;

public enum GalleryStatus {

}
