package com.popups.pupoo.reply.domain.model;

public class Reply {

}
