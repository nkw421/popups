package com.popups.pupoo.reply.application;

public class ReplyTargetValidator {

}
