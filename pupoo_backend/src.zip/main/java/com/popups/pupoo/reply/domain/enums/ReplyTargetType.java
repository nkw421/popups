package com.popups.pupoo.reply.domain.enums;

public enum ReplyTargetType {

}
