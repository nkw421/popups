package com.popups.pupoo.reply.dto;

public class ReplyResponse {

}
