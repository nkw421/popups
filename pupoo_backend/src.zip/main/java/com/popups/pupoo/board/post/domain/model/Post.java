package com.popups.pupoo.board.post.domain.model;

public class Post {

}
