package com.popups.pupoo.board.boardinfo.api;

public class BoardController {

}
