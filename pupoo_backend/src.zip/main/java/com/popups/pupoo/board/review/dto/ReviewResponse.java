package com.popups.pupoo.board.review.dto;

public class ReviewResponse {

}
