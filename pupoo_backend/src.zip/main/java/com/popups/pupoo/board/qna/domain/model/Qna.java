package com.popups.pupoo.board.qna.domain.model;

public class Qna {

}
