package com.popups.pupoo.board.qna.dto;

public class QnaResponse {

}
