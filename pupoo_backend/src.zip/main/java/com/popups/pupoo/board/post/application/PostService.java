package com.popups.pupoo.board.post.application;

public class PostService {

}
