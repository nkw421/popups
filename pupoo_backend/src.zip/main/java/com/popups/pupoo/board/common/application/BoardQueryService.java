package com.popups.pupoo.board.common.application;

public class BoardQueryService {

}
