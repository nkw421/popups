package com.popups.pupoo.board.qna.domain.enums;

public enum QnaStatus {

}
