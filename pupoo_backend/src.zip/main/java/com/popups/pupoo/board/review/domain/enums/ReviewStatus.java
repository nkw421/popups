package com.popups.pupoo.board.review.domain.enums;

public enum ReviewStatus {

}
