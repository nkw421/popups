package com.popups.pupoo.board.review.domain.model;

public class Review {

}
