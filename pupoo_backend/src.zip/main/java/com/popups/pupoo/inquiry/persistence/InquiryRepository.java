package com.popups.pupoo.inquiry.persistence;

public interface InquiryRepository {

}
