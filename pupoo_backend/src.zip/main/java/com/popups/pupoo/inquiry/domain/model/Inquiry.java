package com.popups.pupoo.inquiry.domain.model;

public class Inquiry {

}
