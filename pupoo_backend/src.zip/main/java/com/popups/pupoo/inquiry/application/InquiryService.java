package com.popups.pupoo.inquiry.application;

public class InquiryService {

}
