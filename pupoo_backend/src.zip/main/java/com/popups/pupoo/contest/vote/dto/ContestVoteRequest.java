package com.popups.pupoo.contest.vote.dto;

public record ContestVoteRequest(
        Long programApplyId
) {}
