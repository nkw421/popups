package com.popups.pupoo.contest.vote.domain.enums;

public enum VoteStatus {
    ACTIVE,
    CANCELLED
}
