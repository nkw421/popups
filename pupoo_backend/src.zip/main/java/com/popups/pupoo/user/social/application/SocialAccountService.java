package com.popups.pupoo.user.social.application;

public class SocialAccountService {

}
