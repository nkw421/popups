// src/main/java/com/popups/pupoo/user/dto/AdminUserUpdateRequest.java
package com.popups.pupoo.user.dto;

/**
 * 관리자용 사용자 수정 DTO
 * - 추후 관리자 정책 확정 시 필드/검증을 추가한다.
 */
public class AdminUserUpdateRequest {
}
