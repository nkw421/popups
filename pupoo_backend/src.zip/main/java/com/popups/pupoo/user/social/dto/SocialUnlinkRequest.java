package com.popups.pupoo.user.social.dto;

public class SocialUnlinkRequest {

}
