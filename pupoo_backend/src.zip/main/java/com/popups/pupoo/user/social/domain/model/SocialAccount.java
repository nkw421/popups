package com.popups.pupoo.user.social.domain.model;

public class SocialAccount {

}
