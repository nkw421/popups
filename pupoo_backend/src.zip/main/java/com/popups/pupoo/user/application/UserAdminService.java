package com.popups.pupoo.user.application;

public class UserAdminService {
}
