// src/main/java/com/popups/pupoo/user/domain/enums/RoleName.java
package com.popups.pupoo.user.domain.enums;

public enum RoleName {

    USER,
    ADMIN

}
