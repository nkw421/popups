package com.popups.pupoo.user.social.domain.enums;

public enum SocialProvider {
    GOOGLE,
    KAKAO,
    NAVER,
    APPLE
}
