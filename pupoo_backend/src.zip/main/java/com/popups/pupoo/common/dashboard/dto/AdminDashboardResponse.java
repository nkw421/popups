package com.popups.pupoo.common.dashboard.dto;

public class AdminDashboardResponse {
}
