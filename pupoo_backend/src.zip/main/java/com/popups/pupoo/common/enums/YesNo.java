package com.popups.pupoo.common.enums;

public class YesNo {

}
