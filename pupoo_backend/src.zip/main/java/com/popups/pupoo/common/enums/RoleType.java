package com.popups.pupoo.common.enums;

public enum RoleType {

}
