package com.popups.pupoo.common.dashboard.application;

public class DashboardQueryService {
}
