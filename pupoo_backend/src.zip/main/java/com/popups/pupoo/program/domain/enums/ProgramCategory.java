package com.popups.pupoo.program.domain.enums;

public enum ProgramCategory {
    CONTEST,
    SESSION,
    EXPERIENCE
}
