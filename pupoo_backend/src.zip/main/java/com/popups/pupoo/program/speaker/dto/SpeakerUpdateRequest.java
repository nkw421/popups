package com.popups.pupoo.program.speaker.dto;

public class SpeakerUpdateRequest {

}
