package com.popups.pupoo.program.speaker.domain.enums;

public enum SpeakerRole {
    MAIN,
    GUEST,
    OTHER
}
