package com.popups.pupoo.program.dto;

public class ProgramUpdateRequest {

}
