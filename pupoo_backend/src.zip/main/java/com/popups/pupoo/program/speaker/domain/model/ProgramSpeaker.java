package com.popups.pupoo.program.speaker.domain.model;

public class ProgramSpeaker {

}
