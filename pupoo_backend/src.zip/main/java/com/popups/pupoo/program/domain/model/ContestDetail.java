package com.popups.pupoo.program.domain.model;

public class ContestDetail {

}
