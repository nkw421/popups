package com.popups.pupoo.program.speaker.application;

public class SpeakerAdminService {
}
