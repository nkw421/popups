package com.popups.pupoo.payment.domain.enums;

public enum PaymentTransactionStatus {
    READY, APPROVED, CANCELLED, FAILED
}
