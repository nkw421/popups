// src/main/java/com/popups/pupoo/payment/infrastructure/KakaoPayClient.java
package com.popups.pupoo.payment.infrastructure;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClient;

@Profile("!test")
@Component
public class KakaoPayClient {

    private final RestClient.Builder builder;
    private final KakaoPayProperties props;
    private final ObjectMapper objectMapper = new ObjectMapper();

    private volatile RestClient restClient;

    public KakaoPayClient(RestClient.Builder builder, KakaoPayProperties props) {
        this.builder = builder;
        this.props = props;
    }

    private RestClient client() {
        if (restClient != null) {
            return restClient;
        }

        synchronized (this) {
            if (restClient != null) {
                return restClient;
            }

            String secret = props.secretKey();

            // ✅ 부팅은 허용, 호출 시점에만 막는다.
            if (secret == null || secret.isBlank() || secret.contains("$") || "__MISSING__".equals(secret)) {
                throw new IllegalStateException(
                        "KakaoPay secretKey is missing or not resolved. " +
                        "Set `kakaopay.secret-key` or env `KAKAOPAY_SECRET_KEY_DEV` before calling payment APIs."
                );
            }

            String auth = props.authorizationPrefix() + secret;

            System.out.println("[KakaoPay] init RestClient, authPrefix=" + props.authorizationPrefix()
                    + ", secretLen=" + secret.length());

            restClient = builder
                    .baseUrl(props.baseUrl())
                    .defaultHeader("Authorization", auth)
                    .build();

            return restClient;
        }
    }

    public KakaoPayReadyResponse ready(KakaoPayReadyRequest req) {
        try {
            return client().post()
                    .uri(props.readyPath())
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .body(req)
                    .retrieve()
                    .body(KakaoPayReadyResponse.class);
        } catch (HttpStatusCodeException e) {
            System.out.println("[KakaoPay][READY][ERROR] status=" + e.getStatusCode()
                    + ", body=" + e.getResponseBodyAsString());
            throw e;
        }
    }

    public KakaoPayApproveResponse approve(KakaoPayApproveRequest req) {
        try {
            return client().post()
                    .uri(props.approvePath())
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .body(req)
                    .retrieve()
                    .body(KakaoPayApproveResponse.class);
        } catch (HttpStatusCodeException e) {
            System.out.println("[KakaoPay][APPROVE][ERROR] status=" + e.getStatusCode()
                    + ", body=" + e.getResponseBodyAsString());
            throw e;
        }
    }

    public KakaoPayCancelResponse cancel(KakaoPayCancelRequest req) {
        try {
            return client().post()
                    .uri(props.cancelPath())
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .body(req)
                    .retrieve()
                    .body(KakaoPayCancelResponse.class);
        } catch (HttpStatusCodeException e) {
            System.out.println("[KakaoPay][CANCEL][ERROR] status=" + e.getStatusCode()
                    + ", body=" + e.getResponseBodyAsString());
            throw e;
        }
    }

    public String toJson(Object o) {
        try { return objectMapper.writeValueAsString(o); }
        catch (Exception e) { return "{\"_error\":\"json serialize failed\"}"; }
    }
}
