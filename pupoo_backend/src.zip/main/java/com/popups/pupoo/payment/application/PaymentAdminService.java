package com.popups.pupoo.payment.application;

public class PaymentAdminService {
}
