package com.popups.pupoo.payment.refund.domain.enums;

public enum RefundStatus {
    REQUESTED, APPROVED, REJECTED, COMPLETED
}
