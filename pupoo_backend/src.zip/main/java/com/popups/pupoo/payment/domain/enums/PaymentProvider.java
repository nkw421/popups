package com.popups.pupoo.payment.domain.enums;

public enum PaymentProvider {
    KAKAOPAY, CARD, BANK, OTHER
}
