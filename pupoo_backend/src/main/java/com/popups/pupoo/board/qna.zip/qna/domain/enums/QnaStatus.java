// file: src/main/java/com/popups/pupoo/board/qna/domain/enums/QnaStatus.java
package com.popups.pupoo.board.qna.domain.enums;

public enum QnaStatus {
    OPEN, CLOSED
}
