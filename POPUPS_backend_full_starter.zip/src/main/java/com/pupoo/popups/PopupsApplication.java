package com.pupoo.popups;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PopupsApplication {
    public static void main(String[] args) {
        SpringApplication.run(PopupsApplication.class, args);
    }
}
