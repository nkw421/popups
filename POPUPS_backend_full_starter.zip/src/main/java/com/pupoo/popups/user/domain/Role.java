package com.pupoo.popups.user.domain;

public enum Role { USER, ADMIN }
